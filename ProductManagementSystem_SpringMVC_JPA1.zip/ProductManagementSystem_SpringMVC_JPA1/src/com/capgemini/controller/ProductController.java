package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.entities.Product;
import com.capgemini.service.IProductService;

@Controller
public class ProductController {

	@Autowired
	IProductService productService;

	public ProductController(IProductService productService) {
		super();
		this.productService = productService;
	}

	public ProductController() {
		super();
	}

	public IProductService getProductService() {
		return productService;
	}

	public void setProductService(IProductService productService) {
		this.productService = productService;
	}
	
	//Providing 
	@RequestMapping("home")
	public String getHomePage()
	{
		return "HomePage";
	}
	
	@RequestMapping("addproducts")
	public String getAddProductPage(Model model)
	{
		List<String> categories = new ArrayList<>();
		categories.add("Shoes");
		categories.add("Electronies");
		categories.add("Clothes");
		categories.add("Books");
		categories.add("Furniture");
		
		//Add the form backing bean to be binded to AddProduct.jsp form
		model.addAttribute("product", new Product());
		
		//Add the Categories to build the drop down list in AddProduct dynamic
		model.addAttribute("categories",categories);
		
		//return view name
		return "AddProductPage";
	}
	
	@RequestMapping(value="ProcessAddProductForm")
	public ModelAndView processAddProductForm(@ModelAttribute("product")
	@Valid Product product, BindingResult result, Model model)
	{
		
		if (result.hasErrors() == true)
		{
			//init the sata for category drop down list
			List<String> categories = new ArrayList<>();
			categories.add("Shoes");
			categories.add("Electronies");
			categories.add("Clothes");
			categories.add("Books");
			categories.add("Furniture");
			
			//Add the form backing bean to be binded to AddProduct.jsp form
			model.addAttribute("product", product);
			
			//Add the Categories to build the drop down list in AddProduct dynamic
			model.addAttribute("categories", categories );
			
			
			return new ModelAndView("AddProductPage");
		}
		
		int productId = -1;
		
			try 
			{
			productId = productService.addProduct(product);
				model.addAttribute("message", "Product Added Successfully. Product id:" + productId);
				
				return new ModelAndView("SuccessPage");
			}
			catch (Exception e)
			{
				model.addAttribute("errMsg", "Could not add Product reason. Product id:" + product);
				
				return new ModelAndView("ErrorPage");
			}
	}
	
	@RequestMapping("getproducts")
	public String getProductPage()
	{
		return "GetProductPage";
	}
	
	@RequestMapping("processgetproductform")
	public ModelAndView processGetProductForm(@RequestParam("productId") int pid)
	{
		Product product = null;
		try 
		{
			System.out.println("In");
			product = productService.getProduct(pid);
			return new ModelAndView("GetProductPage", "product", product);
		} 
		catch (Exception e) 
		{
			return new ModelAndView("ErrorPage", "errMsg", "Could not retrive the product.Reason:" + e.getStackTrace());
		}
		
	}
	
	@RequestMapping("ViewallProducts")
	public String getViewAllProductsPage(Model model)
	{
		List<Product> products = null;
		
		try 
		{
			products = productService.getAllProducts();
			model.addAttribute("products", products);
			System.out.println(products);
		}
		catch (Exception e)
		{
			model.addAttribute("errMgs", "Could not display Products. Reason:" + e.getStackTrace());
			return "ErrorPage";
		}
		
		return "ViewAllProductsPage";
	}
	
	@RequestMapping("getupdatepage")
	private String getUpdatePage(@RequestParam("pid") int id,Model model)
	{
		//init the sata for category drop down list
		List<String> categories = new ArrayList<>();
		categories.add("Shoes");
		categories.add("Electronies");
		categories.add("Clothes");
		categories.add("Books");
		categories.add("Furniture");
		
		 Product product = null;
		 try 
		 {
			 product = productService.getProduct(id);
		 }
		 catch (Exception e) 
		 {
			 model.addAttribute("errMsg", "Could not retrive Product, Reason:"+ e.getStackTrace());
			return "ErrorPage";
		 }
		
		
		model.addAttribute("product", product);
		
		//Add the Categories to build the drop down list in AddProduct dynamic
		model.addAttribute("categories", categories );
	
		return "UpdatePage";
	}
	
	@RequestMapping(value="ProcessupdatepageForm", method=RequestMethod.POST)
	public String processUpdatePageForm(@ModelAttribute("product") @Valid Product product, BindingResult result, Model model)
	{
		if( result.hasErrors() == true)
		{
			List<String> categories = new ArrayList<>();
			categories.add("Shoes");
			categories.add("Electronies");
			categories.add("Clothes");
			categories.add("Books");
			categories.add("Furniture");
			
			//Add the form backing bean to be binded to AddProduct.jsp form
			model.addAttribute("product", product);
			
			//Add the Categories to build the drop down list in AddProduct dynamic
			model.addAttribute("categories", categories );
		
			return "UpdatePage";
		}
		
		try 
		{
			productService.updateProduct(product);
		}
		catch (Exception e) 
		{
			model.addAttribute("errMsg", "Could not Update Product Details, Reason");		
			return "ErrorPage";
		}
			model.addAttribute("message", "Product Updated Successfully");		
			return "SuccessPage";
	}
}
